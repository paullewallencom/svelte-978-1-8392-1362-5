<h1>Hello, {name}!</h1>
<p>My first Svelte app</p>

<style>
p {
    color: #1d4585;
}
</style>

<script>
export let name = ''
</script>
