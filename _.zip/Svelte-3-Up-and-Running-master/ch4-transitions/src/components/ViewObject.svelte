<div in:fade>
    <Obj {objectId} />
</div>

<script>
import {fade} from 'svelte/transition'
import Obj from './Obj.svelte'

export let objectId = null
</script>
