<Obj {objectId} />

<script>
import Obj from './Obj.svelte'

export let objectId = null
</script>
