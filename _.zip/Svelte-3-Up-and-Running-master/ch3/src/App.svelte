<ViewAdd />
<script>
import ViewAdd from './components/ViewAdd.svelte'
</script>
